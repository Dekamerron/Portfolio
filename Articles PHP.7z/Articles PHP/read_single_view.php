<?php
require_once('functions.php');

mysql_open();

$id_single = $_GET['id'];
$sql       = "SELECT * FROM article WHERE id='".$id_single."'";
$results   = mysql_query($sql);

while($article = mysql_fetch_assoc($results))
{
	$id_single    = $article['id'];
	$title_single = $article['title'];
	$body_single  = $article['body'];
}


if(isset($_POST['go_back']))
{
	header("Location: read_section.php");
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Black + White | Read Article</title>
	<link href='http://fonts.googleapis.com/css?family=Clicker+Script' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/text.css">
	<link rel="stylesheet" type="text/css" href="css/960_24_col.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link rel="shortcut icon" type="image/x-icon" href="images/article_icon.jpg">
</head>
<body>

<div class="container_24">
<header>
	<a href="home.php"><img src="images/logo.png" width="175px" height="23px" class="logo"></a>
	<h1>Black and White</h1>
	<nav>
		<ul>
			<li><a href="home.php">Home</a></li>
			<li><a href="add_article.php">Create Article</a></li>
			<li><a href="delete_article.php">Delete Article</a></li>
			<li><a href="edit_article.php">Edit Article</a></li>
			<li><a href="read_section.php" class="selected">Read Section</a></li>
		</ul>
	</nav>
</header>
	<div class="main clearfix">
		<div class="grid_24 work">
			<img src="images/read.jpg">
			<?php
				echo "<h4>".$title_single."</h4>";
				echo "<p class ='first'>";	
				echo $body_single;
				echo "</p>";
				echo "<h4></h4>";
			?>
			<form action="" method="POST">
				<input type="submit" class='button' name="go_back" value="Go back">
			</form>
		</div>
	</div>
</div>
</body>
</html>
