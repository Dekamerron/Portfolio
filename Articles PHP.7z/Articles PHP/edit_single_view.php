<?php
require_once('functions.php');

mysql_open();

$id      = $_GET['id'];
$sql     = "SELECT * FROM article WHERE id=$id";
$results = mysql_query($sql);

if(mysql_affected_rows())
{
	$article = mysql_fetch_assoc($results);
}

$id_all[] = $article['id'];
if(!in_array($id, $id_all))
{
	header("Location: edit_article.php");
}

if(isset($_POST['edit_article']))
{
	$title  = mysql_real_escape_string($_POST['article_title']);
	$body   = mysql_real_escape_string($_POST['article_body']);

	$sql = "UPDATE article SET title='".$title."', body='".$body."' WHERE id='".$id."' LIMIT 1";
	$results = mysql_query($sql);

	if(mysql_affected_rows())
	{
		header("Location: edit_article.php");
	}
}
else if(isset($_POST['go_back']))
{
	header("Location: edit_article.php");
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Black + White | Edit Article</title>
	<link href='http://fonts.googleapis.com/css?family=Clicker+Script' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/text.css">
	<link rel="stylesheet" type="text/css" href="css/960_24_col.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link rel="shortcut icon" type="image/x-icon" href="images/article_icon.jpg">
</head>
<body>

<div class="container_24">
<header>
	<a href="home.php"><img src="images/logo.png" width="175px" height="23px" class="logo"></a>
	<h1>Black and White</h1>
	<nav>
		<ul>
			<li><a href="home.php">Home</a></li>
			<li><a href="add_article.php">Create Article</a></li>
			<li><a href="delete_article.php">Delete Article</a></li>
			<li><a href="edit_article.php" class="selected">Edit Article</a></li>
			<li><a href="read_section.php">Read Section</a></li>
		</ul>
	</nav>
	
</header>
	<div class="main clearfix">
		<div class="grid_24 work">
			<img src="images/edit.jpg">
			<form action="" method="POST">
				<h2><label for="article_title">Article title</label></h2>
				<?php 
				if(isset($status))
					{
						echo "<b>$status</b>";
					}
				?>
				<br>
				<input type="text" name="article_title" id="article_title" maxlength="70" size="70" 
				value='<?php echo $article['title']; ?>'>

				<h2><label for="article_body">Article body</label></h2>
				<textarea name="article_body" name="article_body" id="article_body" rows="20" cols="113"><?php echo $article['body']; ?></textarea>

				<input type="submit" value="Edit" name="edit_article" class="button">
				<input type="submit" class='button' name="go_back" value="Go back">
			</form>
		</div>
	</div>
</div>
</body>
</html>
