<?php

function mysql_open() {
	$hostname = "localhost";
	$username = "root";
	$password = "spiderman";
	$database = "articles";

	$conn = mysql_connect($hostname, $username, $password) 
	or die('Сайтът не може да се свърже към базата данни!<br />'. mysql_error());

	mysql_select_db($database, $conn) 
	or die('Сайтът не може да се свърже към базата данни!<br />'. mysql_error());
}