<?php

require_once('functions.php');

mysql_open();

if($_SERVER['REQUEST_METHOD'] == "POST")
{
	$title = mysql_real_escape_string($_POST['article_title']);
	$body  = mysql_real_escape_string($_POST['article_body']);

	$sql    = "INSERT INTO article (title, body) VALUES ('".$title."','".$body."')";
	$result = mysql_query($sql);

	if(mysql_affected_rows())
	{
		$status = "Article successfully added!";
	}
	else
	{
		$status = "There was a error!" . mysql_error();
	}
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Black + White | Create Article</title>
	<link href='http://fonts.googleapis.com/css?family=Clicker+Script' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/text.css">
	<link rel="stylesheet" type="text/css" href="css/960_24_col.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link rel="shortcut icon" type="image/x-icon" href="images/article_icon.jpg">
</head>
<body>

<div class="container_24">
<header>
	<a href="home.php"><img src="images/logo.png" width="175px" height="23px" class="logo"></a>
	<h1>Black and White</h1>
	<nav>
		<ul>
			<li><a href="home.php">Home</a></li>
			<li><a href="add_article.php" class="selected">Create Article</a></li>
			<li><a href="delete_article.php">Delete Article</a></li>
			<li><a href="edit_article.php">Edit Article</a></li>
			<li><a href="read_section.php">Read Section</a></li>
		</ul>
	</nav>
	
</header>
	<div class="main clearfix">
		<div class="grid_12 work">
			<img src="images/work.jpg">
			<form action="" method="POST">
				<h2><label for="article_title">Article title</label></h2>
				<?php 
				if(isset($status))
					{
						echo "<b>$status</b>";
					}
				?>
				<input type="text" name="article_title" id="article_title" maxlength="70" size="70">

				<h2><label for="article_body">Article body</label></h2>
				<textarea name="article_body" name="article_body" id="article_body" rows="20" cols="113"></textarea>

				<input type="submit" value="Submit" name="submit_article" class="button">
			</form>
		</div>
		<div class="grid_12 work create">
			<img src="images/NY.jpg">
		</div>
	</div>
</div>
</body>
</html>
