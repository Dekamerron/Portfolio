<?php

function mysql_open() {
	$hostname = "";
	$username = "";
	$password = "";
	$database = "";

	$conn = mysql_connect($hostname, $username, $password) 
	or die('Сайтът не може да се свърже към базата данни!<br />'. mysql_error());

	mysql_select_db($database, $conn) 
	or die('Сайтът не може да се свърже към базата данни!<br />'. mysql_error());
}