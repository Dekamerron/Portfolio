<?php
require_once('functions.php');

mysql_open();

$sql     = "SELECT * FROM article";
$results = mysql_query($sql);

while($row = mysql_fetch_array($results))
{
	$id[]    = $row['id'];
	$title[] = $row['title'];
	$body[]  = $row['body'];
}


?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Black + White | Edit Article</title>
	<link href='http://fonts.googleapis.com/css?family=Clicker+Script' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/text.css">
	<link rel="stylesheet" type="text/css" href="css/960_24_col.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link rel="shortcut icon" type="image/x-icon" href="images/article_icon.jpg">
</head>
<body>

<div class="container_24">
<header>
	<a href="home.php"><img src="images/logo.png" width="175px" height="23px" class="logo"></a>
	<h1>Black and White</h1>
	<nav>
		<ul>
			<li><a href="home.php">Home</a></li>
			<li><a href="add_article.php">Create Article</a></li>
			<li><a href="delete_article.php">Delete Article</a></li>
			<li><a href="edit_article.php" class="selected">Edit Article</a></li>
			<li><a href="read_section.php">Read Section</a></li>
		</ul>
	</nav>
	
</header>
	<div class="main clearfix">
		<div class="grid_24 work">
			<img src="images/edit.jpg">
			<?php 
			for ($i=0; $i < count($title); $i++)
				{
					echo "<h4>";
					echo "<a href='edit_single_view.php?id=$id[$i]'>".$title[$i]."</a>";
					echo "</h4>";
				}
			?>	
		</div>
	</div>
</div>
</body>
</html>
